import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddbusComponent } from './addbus/addbus.component';
import { ShowbusesComponent } from './showbuses/showbuses.component';
import { LoginComponent } from './login/login.component';
import { ShowusersComponent } from './showusers/showusers.component';


const routes: Routes = [

  {path:'',redirectTo:'/login',pathMatch:'full'},

  {path:'login',component:LoginComponent}, 
{path:'body',component:AdminhomeComponent}, 
{path:'AddBus',component:AddbusComponent}, 
{path:'ShowBus',component:ShowbusesComponent},
{path:'ShowUser',component:ShowusersComponent},



// {path:'body',component:AdminhomeComponent}, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
