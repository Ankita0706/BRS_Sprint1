import { Pipe,PipeTransform } from "@angular/core";

import { Bus } from './app.bus';


@Pipe(
    {name:"searchPipe"}
)
export class SearchPipe implements PipeTransform
{
    transform(bus:Bus[],search:any)
    {
        if(search==undefined)
        return bus;
        return bus.filter(function(bus:Bus){
            console.log("............"+bus);
            return bus.busId.toString(search.toLocaleLowerCase())
        })
    }
}