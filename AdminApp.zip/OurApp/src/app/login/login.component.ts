import { Component, OnInit } from '@angular/core';
import { BusService } from '../busservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:BusService, private router: Router){ }

  user:any={};

  ngOnInit() {
  }

  model:any={};

  login(){
    console.log("Validation Working");
    // console.log(this.user);
    console.log(this.model)
    this.service.login(this.model.username,this.model.password).subscribe(
      data=>{alert("Login successfull");
    this.router.navigate(['body']);
    console.log("1");
  },
  error=>{alert(error.error);
          })
  }

}
