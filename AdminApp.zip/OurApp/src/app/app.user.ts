export class user
{
    userId:number;
    fname: String;
    lname: string;
    username: string;
    password: string;
    email: string;
    phoneno: number;
    DOB:Date;
    adharcardno: number;
}