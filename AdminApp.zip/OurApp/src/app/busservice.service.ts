
import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Bus } from './app.bus';
import { user } from './app.user';

@Injectable({
    providedIn: 'root'
})

export class BusService{

    private baseUrl = 'http://localhost:9099/api';



    temp:any;

    //Dependency Injection
    constructor(private myhttp:HttpClient){}

    getAllBuses(){
        return this.myhttp.get<Bus[]>('http://localhost:9099/api/buses');
    }

   
   
    addBus(data:any){
        //For RequestBody
        //return this.myhttp.post('http://localhost:9088/product/add',data);
        
        //For Model Attribute
        let form=new FormData();
        form.append("busName", data.busName);
        form.append("busType", data.busType);
        form.append("busClass", data.busClass);
        form.append("source", data.source);
        form.append("destination", data.destination);
        form.append("startTime", data.startTime);
        form.append("endTime", data.endTime);
        form.append("costperSeat", data.costPerSeat);
        form.append("noofSeats", data.noOfSeats);

        console.log(data);
        return this.myhttp.post('http://localhost:9099/api/addBus', data);

    }

    deleteBus(id:number){ 
        return this.myhttp.delete(this.baseUrl+'/buses/'+id);
    }

    deleteUser(id:number){ 
        return this.myhttp.delete(this.baseUrl+'/users/'+id);
    }

    showUser(){
        return this.myhttp.get<user[]>('http://localhost:9099/api/users');
    }

    login(username:any,password:any){
        // let form=new FormData();
        // form.append("username", data.username);
        // form.append("password", data.password);
        //console.log(form);
        console.log(password);
        return this.myhttp.get('http://localhost:9099/api/login?username='+username+'&password='+password,{responseType: 'text'});
    }

}